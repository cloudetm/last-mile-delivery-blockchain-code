composer transaction submit -c admin@last-mile-delivery-network -d '{"$class":"org.hyperledger.composer.system.AddParticipant","resources":[{
  "$class": "delivery.Warehouse",
  "id":1,
  "userId": 11,
  "name": "Ajmer Warehouse",
  "address": "Bhagwan Adinath Marg,Kaiser GanjRd,Parao,Ajmer,Rajasthan 305001",
  "latitude": 26.4486874,
  "longitude": 74.6335015,
  "number": "9876543210L",
  "holderId": "TestWarehouse1"
},
{
  "$class": "delivery.Warehouse",
   "id":2,
  "userId": 2,
  "name": "North Warehouse",
  "address": "38/6, Delhi - Jaipur Expy, Mohammed Pur, Khandsha, Sector 37, Gurugram, Haryana 122004",
  "latitude": 30.8908227,
  "longitude": 75.8391252,
  "number": "9876543210L",
  "holderId": "TestWarehouse2"
}],"targetRegistry":"resource:org.hyperledger.composer.system.ParticipantRegistry#delivery.Warehouse"}'

