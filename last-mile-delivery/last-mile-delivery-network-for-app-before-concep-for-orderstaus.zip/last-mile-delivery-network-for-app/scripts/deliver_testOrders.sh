#!/bin/bash
composer transaction submit -c admin@last-mile-delivery-network -d '{
  "$class": "delivery.DeliverOrder",
  "transporter": "resource:delivery.Transporter#TestTransporter1",
  "productHolder": "resource:delivery.Warehouse#TestWarehouse2",
  "historys":[
  "resource:delivery.OrderHistory#TestOrder1",
  "resource:delivery.OrderHistory#TestOrder2"
 ]
}'