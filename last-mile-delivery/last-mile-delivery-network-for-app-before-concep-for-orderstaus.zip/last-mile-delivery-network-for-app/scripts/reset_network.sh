#!/bin/bash
composer network reset -c admin@last-mile-delivery-network
~/Desktop/Business-networks/last-mile-delivery/last-mile-delivery-network-for-app-worked-till-Ajmer-warehouse/scripts/./Place_Orders.sh
~/Desktop/Business-networks/last-mile-delivery/last-mile-delivery-network-for-app-worked-till-Ajmer-warehouse/scripts/./Transporter_data.sh
~/Desktop/Business-networks/last-mile-delivery/last-mile-delivery-network-for-app-worked-till-Ajmer-warehouse/scripts/./Warehouse_data.sh
~/Desktop/Business-networks/last-mile-delivery/last-mile-delivery-network-for-app-worked-till-Ajmer-warehouse/scripts/./Contracts_data.sh
