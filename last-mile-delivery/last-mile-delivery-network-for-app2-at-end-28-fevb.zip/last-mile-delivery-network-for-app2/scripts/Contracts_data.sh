#!/bin/bash
#Contracts
composer transaction submit -c admin@last-mile-delivery-network -d '{"$class":"org.hyperledger.composer.system.AddAsset","resources":[{
  "$class": "delivery.Contract",
  "contractId": "Contract1",
  "pincode": "305001",
  "hubs": [
    {
      "$class": "delivery.Address",
      "name": "North Warehouse",
      "address": "38/6, Delhi - Jaipur Expy, Mohammed Pur, Khandsha, Sector 37, Gurugram, Haryana 122004",
      "latitude": "30.8908227",
      "longitude": "75.8391252"
    },
    {
      "$class": "delivery.Address",
      "name": "Rajasthan Warehouse",
      "address": "Bhawani Singh Road, Jaipur, Rajasthan 302001",
      "latitude": "28.0216219",
      "longitude": "73.2845209"
    }
  ]
},
{
  "$class": "delivery.Contract",
  "contractId": "Contract2",
  "pincode": "302002",
  "hubs": [
    {
      "$class": "delivery.Address",
      "name": "North Warehouse",
      "address": "38/6, Delhi - Jaipur Expy, Mohammed Pur, Khandsha, Sector 37, Gurugram, Haryana 122004",
      "latitude": "30.8908227",
      "longitude": "75.8391252"
    },
    {
      "$class": "delivery.Address",
      "name": "Rajasthan Warehouse",
      "address": "Bhawani Singh Road, Jaipur, Rajasthan 302001",
      "latitude": "28.0216219",
      "longitude": "73.2845209"
    },
    {
      "$class": "delivery.Address",
      "name": "Ajmer Warehouse",
      "address": "Bhagwan Adinath Marg,Kaiser GanjRd,Parao,Ajmer,Rajasthan 305001",
      "latitude": "26.4486874",
      "longitude": "74.6335015"
    }
  ]
}],"targetRegistry":"resource:org.hyperledger.composer.system.AssetRegistry#delivery.Contract"}'
