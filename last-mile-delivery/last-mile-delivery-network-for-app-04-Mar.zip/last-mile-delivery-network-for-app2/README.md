# delivery
int RECEIVE_CONFIRMATION_PENDING = 1;
        int NEW_ORDER = 2;
        int ASSIGNED = 3;
        int ACCEPTED = 4;
        int IN_TRANSIT = 5;
        int DELIVERED = 6;

Warehouse history for place order working, warehouse history for accept order working , also changed the property of location and estimated time to delivery fields in transporter after delivery orders to not change, warehouse history for place, assign, deliver and scan orders done not tested"
