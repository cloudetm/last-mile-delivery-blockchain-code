#!/bin/bash
composer transaction submit -c admin@last-mile-delivery-network -d '{
 "$class": "delivery.AcceptOrder",
 "transporter": "resource:delivery.Transporter#TestTransporter1",
 "historys": [
  "resource:delivery.OrderHistory#TestOrder1",
  "resource:delivery.OrderHistory#TestOrder2"
 ]
 }'
