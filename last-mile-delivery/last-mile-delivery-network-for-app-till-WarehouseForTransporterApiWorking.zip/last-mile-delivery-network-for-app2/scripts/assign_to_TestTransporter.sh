#!/bin/bash
# assign orders to transporter
composer transaction submit -c admin@last-mile-delivery-network -d '{
  "$class": "delivery.AssignTransporter",
  "DeliveryId": "TestDelivery1",
  "transporter": "resource:delivery.Transporter#TestTransporter1",
  "EstimatedTime": "1 day",
  "ToLocation": "Jaipur",
  "orders": ["resource:delivery.Order#TestOrder1","resource:delivery.Order#TestOrder2"],
  "historys": ["resource:delivery.OrderHistory#TestOrder1","resource:delivery.OrderHistory#TestOrder2"]
}'
