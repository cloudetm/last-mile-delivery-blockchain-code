#!/bin/bash
composer transaction submit -c admin@last-mile-delivery-network -d '{"$class":"org.hyperledger.composer.system.AddParticipant","resources":[{
  "$class": "delivery.Transporter",
  "DriverFirstName": "Charlie",
  "DriverLastName": "Day",
  "TransporterName": "Balaji Ltd.",
  "VehicleNumber": "323423",
  "VehicleId": "2323",
  "emailId": "trans1@q3.co",
  "DeliveryId": "",
  "orders": [],
  "deliveredOrders":[],
  "StatusId": 0,
  "location": "Gurgaon",
  "holderId": "GurgaonToJaipur"
},
{
  "$class": "delivery.Transporter",
  "DriverFirstName": "Andy",
  "DriverLastName": "Garcia",
  "TransporterName": "K.K.Sons",
  "VehicleNumber": "323423",
  "VehicleId": "2423",
  "emailId": "trans2@q3.co",
  "DeliveryId": "",
  "orders": [],
  "deliveredOrders":[],
  "StatusId": 0,
  "location": "Jaipur",
  "holderId": "JaipurToAjmer"
}],"targetRegistry":"resource:org.hyperledger.composer.system.ParticipantRegistry#delivery.Transporter"}'
