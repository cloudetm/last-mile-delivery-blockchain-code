#!/bin/bash
composer network reset -c admin@last-mile-delivery-network
scripts/./Place_Orders.sh
scripts/./Transporter_data.sh
scripts/./Warehouse_data.sh
scripts/./Contracts_data.sh
