#!/bin/bash
composer transaction submit -c admin@last-mile-delivery-network -d '{
  "$class": "delivery.DeliverOrder",
  "transporter": "resource:delivery.Transporter#JaipurToAjmer",
  "productHolder": "resource:delivery.Warehouse#WarehouseAjmer",
  "historys":["resource:delivery.OrderHistory#OrderAjmer1","resource:delivery.OrderHistory#OrderAjmer2"]
}'