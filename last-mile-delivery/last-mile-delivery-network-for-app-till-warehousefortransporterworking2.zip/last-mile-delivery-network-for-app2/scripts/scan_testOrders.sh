#!/bin/bash
composer transaction submit -c admin@last-mile-delivery-network -d '{
  "$class": "delivery.ScanProductsInWarehouse",
  "warehouse": "resource:delivery.Warehouse#TestWarehouse2",
  "orders": [
  "resource:delivery.Order#TestOrder1",
  "resource:delivery.Order#TestOrder2"
 ],
  "historys": [
  "resource:delivery.OrderHistory#TestOrder1",
  "resource:delivery.OrderHistory#TestOrder2"
 ]
}'