#!/bin/bash
composer transaction submit -c admin@last-mile-delivery-network -d '{"$class":"org.hyperledger.composer.system.AddParticipant","resources":[
  {
  "$class": "delivery.WarehouseForTransporter",
  "id":1,
  "userId": 11,
  "name": "Ajmer Warehouse",
  "address": "Bhagwan Adinath Marg,Kaiser GanjRd,Parao,Ajmer,Rajasthan 305001",
  "latitude": 26.4486874,
  "longitude": 74.6335015,
  "number": "9876543210L",
  "holderId": "WarehouseAjmer",
  "EstimatedTimeForDelivery": "",
  "TransporterName": "GurgaonToJaipur"
},
{
  "$class": "delivery.WarehouseForTransporter",
  "id":3,
  "userId": 6,
  "name": "Rajasthan Warehouse",
  "address": "Bhawani Singh Road, Jaipur, Rajasthan 302001",
  "latitude": 28.0216219,
  "longitude": 73.2845209,
  "number": "9876543210L",
  "holderId": "WarehouseJaipur",
  "EstimatedTimeForDelivery": "",
  "TransporterName": "JaipurToAjmer"
}],"targetRegistry":"resource:org.hyperledger.composer.system.ParticipantRegistry#delivery.WarehouseForTransporter"}'

