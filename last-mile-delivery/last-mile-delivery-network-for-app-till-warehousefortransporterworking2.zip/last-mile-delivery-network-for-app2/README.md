# delivery
int RECEIVE_CONFIRMATION_PENDING = 1;
        int NEW_ORDER = 2;
        int ASSIGNED = 3;
        int ACCEPTED = 4;
        int IN_TRANSIT = 5;
        int DELIVERED = 6;